The following is a list of assets used in the bitcoin source and their proper attribution.

Jonas Schnelli
-----------------------

### Info
* Designer: Jonas Schnelli (based on the original bitcoin logo from Bitboy)
* License: MIT

### Assets Used
	src/qt/res/icons/bitcoin.icns, src/qt/res/src/bitcoin.svg,
	src/qt/res/src/bitcoin.ico, src/qt/res/src/bitcoin.png,
	src/qt/res/src/bitcoin_testnet.png, docs/bitcoin_logo_doxygen.png,
	src/qt/res/images/splash.png, src/qt/res/images/splash_testnet.png
